import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { getTokenFromLocalStorage } from './authSlice';
import { User } from '@/app/lib/types';


interface UsersState {
  users: User[];
  loading: boolean;
  error: string | null;
  page: number;
  pageSize: number;
  total: number;
}

// Async fetch with pagination (page starts at 1)
export const fetchUsers = createAsyncThunk<
  { users: User[], total: number },
  { page?: number, pageSize?: number }
>('users/fetchAll', async ({ page = 1, pageSize = 10 } = {}, { rejectWithValue }) => {
  const token = getTokenFromLocalStorage();
  const res = await fetch('/api/user', {
    headers: { Authorization: `Bearer ${token}` }
  });
  const json = await res.json();
  if (!json.success) return rejectWithValue(json.error || "Fetch failed");
  // Simulated paging: slice on client; in future use backend paging API
  const users = json.data;
  const start = (page - 1) * pageSize, end = page * pageSize;
  return { users: users.slice(start, end), total: users.length };
});

const userSlice = createSlice({
  name: 'users',
  initialState: {
    users: [] as User[],
    loading: false,
    error: null,
    page: 1,
    pageSize: 10,
    total: 0,
  } as UsersState,
  reducers: {
    setPage(state, action) {
      state.page = action.payload;
    }
  },
  extraReducers: builder => {
    builder
      .addCase(fetchUsers.pending, (s) => { s.loading = true; s.error = null; })
      .addCase(fetchUsers.fulfilled, (s, a) => {
        s.loading = false;
        s.users = a.payload.users;
        s.total = a.payload.total;
      })
      .addCase(fetchUsers.rejected, (s, a) => {
        s.loading = false;
        s.error = a.payload as string;
      });
  }
});
export const { setPage } = userSlice.actions;
export default userSlice.reducer;
