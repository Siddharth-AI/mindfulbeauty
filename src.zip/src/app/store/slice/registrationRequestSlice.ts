import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { getTokenFromLocalStorage } from './authSlice';
import { RegistrationRequest } from '@/app/lib/types';

interface ReqState {
  requests: RegistrationRequest[];
  loading: boolean;
  error: string | null;
  page: number;
  pageSize: number;
  total: number;
}

export const fetchRequests = createAsyncThunk<
  { requests: RegistrationRequest[], total: number },
  { page?: number, pageSize?: number }
>('requests/fetchAll', async ({ page = 1, pageSize = 10 } = {}, { rejectWithValue }) => {
  const token = getTokenFromLocalStorage();
  const res = await fetch('/api/registration-request', {
    headers: { Authorization: `Bearer ${token}` }
  });
  const json = await res.json();
  if (!json.success) return rejectWithValue(json.error || "Fetch failed");
  // Simulated paging
  const reqs = json.data;
  const start = (page - 1) * pageSize, end = page * pageSize;
  return { requests: reqs.slice(start, end), total: reqs.length };
});

export const updateRequestStatus = createAsyncThunk(
  'requests/updateStatus',
  async ({
    requestId, new_status, remark
  }: { requestId: string; new_status: string; remark: string }, { rejectWithValue }) => {
    const token = getTokenFromLocalStorage();
    const res = await fetch(`/api/registration-request/${requestId}/status`, {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ new_status, remark }),
    });
    const json = await res.json();
    if (!json.success) return rejectWithValue(json.error || "Update failed");
    return json.data;
  }
);

const requestSlice = createSlice({
  name: 'registrationRequest',
  initialState: {
    requests: [],
    loading: false,
    error: null,
    page: 1,
    pageSize: 10,
    total: 0,
  } as ReqState,
  reducers: {
    setPage(state, action) { state.page = action.payload; }
  },
  extraReducers: builder => {
    builder
      .addCase(fetchRequests.pending, s => { s.loading = true; s.error = null; })
      .addCase(fetchRequests.fulfilled, (s, a) => {
        s.loading = false;
        s.requests = a.payload.requests;
        s.total = a.payload.total;
      })
      .addCase(fetchRequests.rejected, (s, a) => {
        s.loading = false;
        s.error = a.payload as string;
      });
  }
});

export const { setPage } = requestSlice.actions;
export default requestSlice.reducer;
