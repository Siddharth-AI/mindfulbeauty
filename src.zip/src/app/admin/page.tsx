"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useAppDispatch, useAppSelector } from "@/app/store/hooks";
import { login } from "@/app/store/slice/authSlice";
import { HiEye, HiEyeOff } from "react-icons/hi"; // <--- REACT ICONS
import {
  toastError,
  toastInfo,
  toastSuccess,
} from "../components/common/toastService";

export default function AdminLogin() {
  const dispatch = useAppDispatch();
  const router = useRouter();
  const { loading } = useAppSelector((state) => state.auth);

  const [showPassword, setShowPassword] = useState(false);
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!identifier || !password) {
      toastInfo("Please enter both email and password");
      return;
    }
    const result = await dispatch(login({ identifier, password }));
    if (login.fulfilled.match(result)) {
      toastSuccess("Login successful!");
      setTimeout(() => router.push("/admin/dashboard"), 1200);
    } else if (login.rejected.match(result)) {
      toastError((result.payload as string) || "Login failed");
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-fuchsia-600 via-indigo-600 to-purple-400 animate-gradientbg relative overflow-hidden">
      {/* Background animation */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute -inset-20 blur-3xl opacity-40"
          style={{
            background:
              "radial-gradient(circle at 80% 20%, #fff0 30%, #e0aaff 100%)",
          }}
        />
      </div>
      <ToastContainer />
      <form
        className="z-10 w-full max-w-sm bg-white/80 backdrop-blur-lg rounded-2xl shadow-2xl p-8 border border-purple-200 animate-fadein"
        onSubmit={handleSubmit}>
        <h2 className="text-3xl text-center bg-gradient-to-r from-fuchsia-600 to-indigo-500 bg-clip-text text-transparent font-bold mb-6 tracking-tight">
          Admin Login
        </h2>
        <div className="mb-5">
          <label className="block font-semibold text-gray-700 mb-2">
            Email or Mobile
          </label>
          <input
            type="text"
            className="w-full px-4 py-3 rounded-md border outline-none focus:ring-2 focus:ring-indigo-400 bg-white/90 text-gray-900 transition"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            placeholder="Enter email or phone"
            disabled={loading}
            autoFocus
            required
          />
        </div>
        <div className="mb-6 relative">
          <label className="block font-semibold text-gray-700 mb-2">
            Password
          </label>
          <div className="relative">
            <input
              type={showPassword ? "text" : "password"}
              className="w-full px-4 py-3 rounded-md border outline-none focus:ring-2 focus:ring-pink-400 bg-white/90 text-gray-900 transition"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
              disabled={loading}
              required
              autoComplete="current-password"
            />
            <button
              type="button"
              tabIndex={-1}
              className="absolute right-4 top-6 -translate-y-1/2 text-gray-400 hover:text-indigo-500 focus:outline-none"
              onClick={() => setShowPassword((v) => !v)}
              aria-label={showPassword ? "Hide password" : "Show password"}>
              {showPassword ? (
                <HiEyeOff className="w-5 h-5" />
              ) : (
                <HiEye className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-gradient-to-r from-fuchsia-600 to-indigo-600 hover:from-fuchsia-700 hover:to-indigo-700 text-white font-bold py-3 rounded-md shadow transition transform hover:-translate-y-0.5 active:scale-95 focus:outline-none focus:ring-2 focus:ring-pink-300 tracking-wide">
          {loading ? "Logging in…" : "Login"}
        </button>
        <p className="mt-5 text-center text-gray-400 text-xs">
          Powered by Mindful Beauty
        </p>
      </form>
      {/* Keyframes for fadein background */}
      <style>{`
        @keyframes gradientbg {
          0%,100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        .animate-gradientbg { animation: gradientbg 16s ease infinite; }
        @keyframes fadein { from { opacity: 0; translate: 0 20px; } to { opacity: 1; translate: 0 0; } }
        .animate-fadein { animation: fadein 0.8s .1s backwards; }
      `}</style>
    </div>
  );
}
